package com.phattai.finalproject.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Token")
public class Token {
	@Id
	@Column(name = "strtoken")
	private String strtoken;
	
	@Column(name = "enabled")
    private boolean enabled;

	public String getStrtoken() {
		return strtoken;
	}

	public void setStrtoken(String strtoken) {
		this.strtoken = strtoken;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public Token(String strtoken, boolean enabled) {
		super();
		this.strtoken = strtoken;
		this.enabled = enabled;
	}
	
}
