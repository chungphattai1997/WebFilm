package com.phattai.finalproject.repository;

import org.springframework.data.repository.CrudRepository;

import com.phattai.finalproject.model.Token;

public interface TokenRepository extends CrudRepository<Token, String> {

}
