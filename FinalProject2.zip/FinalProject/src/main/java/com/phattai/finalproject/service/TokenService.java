package com.phattai.finalproject.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.phattai.finalproject.model.Token;
import com.phattai.finalproject.repository.TokenRepository;

@Service
public class TokenService {
	
	@Autowired
	TokenRepository tokenRepository;
	
	public void save(Token token) {
		tokenRepository.save(token);
	}
}
